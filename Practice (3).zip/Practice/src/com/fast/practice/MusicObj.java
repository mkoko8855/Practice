package com.fast.practice;

import java.util.ArrayList;
import java.util.Scanner;

public class MusicObj {
	public static ArrayList<Order> basket = new ArrayList<>(); 
	public static ArrayList<Product> products = new ArrayList<>();

	public static Scanner sc = new Scanner(System.in);
	public static String cmd;

	public static void productLoad() {
		products.add(new Product("발라드", 50000)); 
		products.add(new Product("락발라드", 40000));
	}
}

//배열을 처음 정의할 때, 길이지정하면 변경X
//ArrayList는 추가되는 데이터 수에 따라 길이가 자동으로 변경됨



//ArrayList >  용량 초과 시 크기가 자동 증가되는 동적 배열이 만들어짐
//원소를 할당하기 위해 add()메서드 사용

