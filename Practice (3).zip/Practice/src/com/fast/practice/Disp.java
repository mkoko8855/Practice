package com.fast.practice;

import com.fast.prior.Cw;

public class Disp {
	String x="x"; // 일반멤버변수

	static String star = "★";

	public static void line() { 
		for(int i=0;i<8;i++) {
			Cw.w(star); 
		}
		Cw.wn();
	}

	public static void title() {
		line();
		Cw.wn("** 노래 **");
		line();
		Cw.wn("-------------------------------------");
		
	}

}
