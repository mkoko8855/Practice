package com.fast.practice;

public class Order {
	
	public Product selectedProduct;
	public int OptionHotCold = 0;
	
	
	public Order(Product selectedProduct) {
		this.selectedProduct = selectedProduct;
	}
	public Order(Product selectedProduct, int OptionHotCold) {
		this.selectedProduct = selectedProduct;
		this.OptionHotCold = OptionHotCold;
	}
}
