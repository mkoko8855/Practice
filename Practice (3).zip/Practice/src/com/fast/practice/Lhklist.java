package com.fast.practice;

import com.fast.prior.Cw;

public class Lhklist {
	
	public static void run() {
		loop:while(true) {
			Cw.wn("[1.사랑앓이/2.천둥/3.너올때까지/x.이전으로]");
			MusicObj.cmd = MusicObj.sc.next();
			switch(MusicObj.cmd) {
			case "1":
				Cw.wn("사랑앓이, 이전으로");
				MusicObj.basket.add(new Order(MusicObj.products.get(0),1));	
				break loop;
			case "2":
				Cw.wn("천둥, 이전으로");
				MusicObj.basket.add(new Order(MusicObj.products.get(0),2));	
				break loop;
			case "3":
				Cw.wn("너올때까지, 이전으로");
				MusicObj.basket.add(new Order(MusicObj.products.get(0),3));	
				break loop;
			case "x":
				Cw.wn("이전으로");
				break loop;
			}
		}
	}
}
