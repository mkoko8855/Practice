package com.fast.practice;

import java.util.ArrayList;
import java.util.Scanner;
import com.fast.prior.Cw;

public class Music {

	void run() {
		MusicObj.productLoad(); // 노래
		Disp.title();
		xx: while (true) {
			Cw.wn("가수선택 : [1.발라드/2.락발라드/e.종료]");
		MusicObj.cmd = MusicObj.sc.next(); // 공백이전까지문자열받음
		switch (MusicObj.cmd) {
		case "1":
			Ballad.run();
			break;
		case "2":
			Rockballad.run();
			break;
		case "e":
			Cw.wn("장바구니에 넣은 앨범 갯수:" + MusicObj.basket.size());
			int sum = 0;
			for (Order o:MusicObj.basket) { // 향상된for문(for-each)적용
				sum = sum + o.selectedProduct.price;
			}
			Cw.wn("구매하신 앨범 총가격은 :" + sum + "원 입니다.");

			Cw.wn("===================="); 
			for (Order o : MusicObj.basket) {
				Cw.wn(o.selectedProduct.name);
			}
			Cw.wn("====================");
			Cw.wn("프로그램종료");
			break xx;
		}
		}
	}
}
