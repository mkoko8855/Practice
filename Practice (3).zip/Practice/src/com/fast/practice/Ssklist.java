package com.fast.practice;

import com.fast.prior.Cw;

public class Ssklist {
	
	public static void run() {
		loop:while(true) {
			Cw.wn("[1.거리에서/2.희재/3.크리스마스니까/x.이전으로]");
			MusicObj.cmd = MusicObj.sc.next();
			switch(MusicObj.cmd) {
			case "1":
				Cw.wn("거리에서, 이전으로");
				MusicObj.basket.add(new Order(MusicObj.products.get(0),1));	
				break loop;
			case "2":
				Cw.wn("희재, 이전으로");
				MusicObj.basket.add(new Order(MusicObj.products.get(0),2));	
				break loop;
			case "3":
				Cw.wn("크리스마스니까, 이전으로");
				MusicObj.basket.add(new Order(MusicObj.products.get(0),3));	
				break loop;
			case "x":
				Cw.wn("이전으로");
				break loop;
			}
		}
	}
}
