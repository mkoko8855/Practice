package com.fast.practice;

import com.fast.prior.Cw;

public class Isulist {
	
	public static void run() {
		loop:while(true) {
			Cw.wn("[1.미련한가슴아/2.눈물/3.어디에도/x.이전으로]");
			MusicObj.cmd = MusicObj.sc.next();
			switch(MusicObj.cmd) {
			case "1":
				Cw.wn("미련한가슴아, 이전으로");
				MusicObj.basket.add(new Order(MusicObj.products.get(0),1));	
				break loop;
			case "2":
				Cw.wn("눈물, 이전으로");
				MusicObj.basket.add(new Order(MusicObj.products.get(0),2));	
				break loop;
			case "3":
				Cw.wn("어디에도, 이전으로");
				MusicObj.basket.add(new Order(MusicObj.products.get(0),3));	
				break loop;
			case "x":
				Cw.wn("이전으로");
				break loop;
			}
		}
	}
}
