package com.fast.practice;

import com.fast.prior.Cw;

public class Rockballad {
	
	public static void run() {
		
		for(Product p:MusicObj.products) {	//메뉴출력
			Cw.wn(p.name + " " + p.price + "원");
		}
		yy:while(true) {
			Cw.wn("[1.이수/2.이홍기/x.이전으로]");
			MusicObj.cmd = MusicObj.sc.next();
			switch(MusicObj.cmd) {
			case "1":
				Isulist.run();
				Cw.wn(MusicObj.products.get(1).name+"선택");
				break;
			case "2":
				Lhklist.run();
				Cw.wn(MusicObj.products.get(1).name+"선택");
				Order n = new Order (MusicObj.products.get(1));
				MusicObj.basket.add(n);
//				MusicObj.basket.add(new Order(MusicObj.products.get(1)));	
				break;
			case "x":
				Cw.wn("이전으로");
				break yy;
			}
		}
	}
}
