package com.fast.practice;


public class Product {
	String name;
	int price;
	
	Product(String xx, int yy){
		name = xx;
		price = yy;
	}
	
	void info() {
		System.out.println("가수이름:"+name+" 앨범가격:"+price);
	}
	
}