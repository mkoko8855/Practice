package com.fast.practice;
import com.fast.prior.Cw;

public class Ballad {

	public static void run() {
		for (Product p : MusicObj.products) { //향상된for문>ArrayList원소출력하기위함
			Cw.wn(p.name + " " + p.price + "원"); //반복이 이루어질때마다 배열 항목을 순서대로 꺼내어 변수에 자동 대입
		}
		yy: while (true) {

			Cw.wn("[1.성시경/2.정승환/x.목록]");
			MusicObj.cmd = MusicObj.sc.next();
			switch (MusicObj.cmd) {
			case "1":
				Ssklist.run();
				break;
			case "2":
				Jshlist.run();
				break;
			case "x":
				Cw.wn("이전으로");
				break yy;
			}
		}
	}
}


// public : 메소드가 표시되고 다른 유형의 다른 객체에서 호출될 수 있음을 의미.
// 다른 패키지의 클래스에서 메소드를 볼 수 있음을 의미.

// static메서드가 해당 클래스의 특정 인스턴스(객체)가 아니라 클래스와 연결되어 있음을 의미.
// 즉, 클래스의 객체를 만들지 않고 정적 메서드를 호출할 수 있음.


// void메서드에 반환 값이 없음을 의미 = 리턴X